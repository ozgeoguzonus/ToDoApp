//
//  ToDoListAppApp.swift
//  ToDoListApp
//
//  Created by Özge Oğuz on 24.03.2024.
//
import FirebaseCore
import SwiftUI

@main
struct ToDoListAppApp: App {
    init () {
        FirebaseApp.configure()
    }
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
