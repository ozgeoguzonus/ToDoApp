//
//  ToDoListItemViewViewModel.swift
//  ToDoListApp
//
//  Created by Özge Oğuz on 24.03.2024.
//
import FirebaseAuth
import FirebaseFirestore
import Foundation
///ViewModel for single to do list ıtem view (each row in items list)
///Primary lab
class ToDoListItemViewViewModel: ObservableObject {
    init () {}
    
    func toggleIsDone(item: ToDoListItem) {
        var itemCopy = item
        itemCopy.setDone(!item.isDone)
        
        guard let uid = Auth.auth().currentUser?.uid else {
            return
        }
        let db = Firestore.firestore()
        db.collection("users")
            .document(uid)
            .collection("todos")
            .document(itemCopy.id)
            .setData(itemCopy.asDictionary())
    }
}
